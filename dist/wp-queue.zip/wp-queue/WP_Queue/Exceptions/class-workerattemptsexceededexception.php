<?php
/**
 * WorkerAttemptsExceededException class files.
 *
 * @package WP_Queue
 */

namespace WP_Queue\Exceptions;

use Exception;

/**
 * WorkerAttemptsExceededException class.
 */
class WorkerAttemptsExceededException extends Exception {
}

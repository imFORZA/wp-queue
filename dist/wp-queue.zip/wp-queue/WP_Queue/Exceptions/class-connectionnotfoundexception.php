<?php
/**
 * ConnectionNotFoundException class files.
 *
 * @package WP_Queue
 */

namespace WP_Queue\Exceptions;

use Exception;

/**
 * ConnectionNotFoundException class.
 */
class ConnectionNotFoundException extends Exception {
}
